package practize;

public class Test {

	public static void main(String[] args) {

		
	}

	private void test(){
		//sgetClass().getClassLoader().getResourceAsStream(arg0);
	}
}
