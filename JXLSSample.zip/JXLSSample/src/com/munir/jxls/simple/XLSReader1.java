package com.munir.jxls.simple;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jxls.reader.ReaderBuilder;
import net.sf.jxls.reader.XLSReadStatus;
import net.sf.jxls.reader.XLSReader;

public class XLSReader1 {

	private static String configFileName = "C:/Ramz_Trainingz/JXLS/Code_and_samples/reading/config/sampleInput.xml";
	private static String inputFileName = "C:/Ramz_Trainingz/JXLS/Code_and_samples/reading/input/reader_input.xls";
	 
	public static void main(String[] args) throws Exception {
	
		new XLSReader1().read();

	}
	
	public void read() throws Exception {
		
		InputStream inputXML = new BufferedInputStream(new FileInputStream(configFileName));
        XLSReader mainReader =  ReaderBuilder.buildFromXML( inputXML );
        InputStream inputXLS = new BufferedInputStream(new FileInputStream(inputFileName));
       
        Department department = new Department();
        Map beans = new HashMap();
        beans.put("department", department);
              
        
        System.out.println("Before reading : "+department.getDeptName());
       XLSReadStatus readStatus = mainReader.read( inputXLS, beans);
       
       System.out.println("After reading" + department.getDeptName());
       
       for(int i = 0; i< department.getEmployees().size(); i++){
    	   System.out.println(((Employee)department.getEmployees().get(i)).getEmpName());
       }
	}

}
