package com.munir.jxls.simple;


public class Employee {
	
	public String empName;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	
}
