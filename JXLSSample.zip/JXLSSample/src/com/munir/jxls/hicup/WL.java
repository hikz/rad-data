package com.munir.jxls.hicup;

public class WL {

	public double wlVal;

	public double getWlVal() {
		return wlVal;
	}

	public void setWlVal(double wlVal) {
		this.wlVal = wlVal;
	}
	
	
}
