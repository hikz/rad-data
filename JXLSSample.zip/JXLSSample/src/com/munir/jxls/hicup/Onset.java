package com.munir.jxls.hicup;

public class Onset {

	public double onsetVal;

	public double getOnsetVal() {
		return onsetVal;
	}

	public void setOnsetVal(double onsetVal) {
		this.onsetVal = onsetVal;
	}		
}
