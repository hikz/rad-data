package com.munir.jxls.hicup;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import net.sf.jxls.reader.ReaderBuilder;
import net.sf.jxls.reader.XLSReadStatus;
import net.sf.jxls.reader.XLSReader;


public class HICUPTest {
	private static String configFileName = "C:/Ramz_Trainingz/JXLS/Code_and_samples/reading/config/sampleInput_Data.xml";
	private static String inputFileName = "C:/Ramz_Trainingz/JXLS/Code_and_samples/reading/input/reader_input_data.xls";
	 
	public static void main(String[] args) throws Exception {
	
		new HICUPTest().read();

	}
	
	public void read() throws Exception {
		
		InputStream inputXML = new BufferedInputStream(new FileInputStream(configFileName));
        XLSReader mainReader =  ReaderBuilder.buildFromXML( inputXML );
        InputStream inputXLS = new BufferedInputStream(new FileInputStream(inputFileName));
       
        Onset onset = new Onset();
        WL wl = new WL();
        Map beans = new HashMap();
        beans.put("onset", onset);
        beans.put("wl", wl);
              
        
        System.out.println("Before reading : "+ onset.getOnsetVal());
        System.out.println("Before reading : "+ wl.getWlVal());
        XLSReadStatus readStatus = mainReader.read( inputXLS, beans);
       
       System.out.println("After reading : "+ onset.getOnsetVal());
       System.out.println("After reading : "+ wl.getWlVal());
      
	}
}
